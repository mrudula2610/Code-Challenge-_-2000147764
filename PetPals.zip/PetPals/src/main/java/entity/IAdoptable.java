package entity;

public interface IAdoptable {
    void adopt();
}
