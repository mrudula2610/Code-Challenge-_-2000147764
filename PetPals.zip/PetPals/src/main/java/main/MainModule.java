package main;

import dao.IPetDAO;
import dao.PetDAOImpl;
import entity.*;
import exception.AdoptionException;
import exception.InsufficientFundsException;
import exception.InvalidPetAgeException;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class MainModule {
    private static IPetDAO petDAO;
    private static final PetShelter shelter = new PetShelter();
    private static final AdoptionEvent event = new AdoptionEvent();
    private static final Scanner scanner = new Scanner(System.in);

    static {
        try {
            petDAO = new PetDAOImpl();
        } catch (Exception e) {
            System.out.println("Failed to initialize database connection: " + e.getMessage());
            System.exit(1);
        }
    }

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n--- PetPals Menu ---");
            System.out.println("1. Add Pet");
            System.out.println("2. Remove Pet");
            System.out.println("3. List Available Pets");
            System.out.println("4. Record Cash Donation");
            System.out.println("5. Host Adoption Event");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            try {
                switch (choice) {
                    case 1:
                        addPet();
                        break;
                    case 2:
                        removePet();
                        break;
                    case 3:
                        listAvailablePets();
                        break;
                    case 4:
                        recordCashDonation();
                        break;
                    case 5:
                        hostAdoptionEvent();
                        break;
                    case 6:
                        System.out.println("Exiting PetPals...");
                        scanner.close();
                        System.exit(0);
                    default:
                        System.out.println("Invalid option!");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    // Rest of the methods remain unchanged
    private static void addPet() throws Exception {
        System.out.print("Enter pet ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter pet name: ");
        String name = scanner.nextLine();
        System.out.print("Enter pet age: ");
        int age = scanner.nextInt();
        if (age <= 0) {
            throw new InvalidPetAgeException("Pet age must be positive!");
        }
        scanner.nextLine();
        System.out.print("Enter pet breed: ");
        String breed = scanner.nextLine();
        System.out.print("Is it a Dog or Cat? (D/C): ");
        String type = scanner.nextLine();

        Pet pet;
        if (type.equalsIgnoreCase("D")) {
            System.out.print("Enter dog breed: ");
            String dogBreed = scanner.nextLine();
            pet = new Dog(id, name, age, breed, false, dogBreed);
        } else if (type.equalsIgnoreCase("C")) {
            System.out.print("Enter cat color: ");
            String catColor = scanner.nextLine();
            pet = new Cat(id, name, age, breed, false, catColor);
        } else {
            pet = new Pet(id, name, age, breed, false);
        }

        petDAO.addPet(pet);
        shelter.addPet(pet);
        System.out.println("Pet added successfully!");
    }

    private static void removePet() throws Exception {
        System.out.print("Enter pet ID to remove: ");
        int petId = scanner.nextInt();
        petDAO.removePet(petId);
        System.out.println("Pet removed successfully!");
    }

    private static void listAvailablePets() {
        List<Pet> pets = petDAO.listAvailablePets();
        if (pets.isEmpty()) {
            System.out.println("No available pets.");
        } else {
            pets.forEach(System.out::println);
        }
    }

    private static void recordCashDonation() throws InsufficientFundsException {
        System.out.print("Enter donation ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter donor name: ");
        String donorName = scanner.nextLine();
        System.out.print("Enter donation amount: ");
        double amount = scanner.nextDouble();
        if (amount < 10) {
            throw new InsufficientFundsException("Donation amount must be at least $10!");
        }
        CashDonation donation = new CashDonation(id, donorName, amount, LocalDate.now());
        donation.recordDonation();
    }

    private static void hostAdoptionEvent() throws AdoptionException {
        System.out.print("Register a participant (pet ID): ");
        int petId = scanner.nextInt();
        List<Pet> pets = petDAO.listAvailablePets();
        Pet petToAdopt = pets.stream().filter(p -> p.getId() == petId).findFirst().orElse(null);
        if (petToAdopt == null) {
            throw new AdoptionException("Pet not available for adoption!");
        }
        event.registerParticipant(() -> System.out.println(petToAdopt.getName() + " adopted!"));
        event.hostEvent();
    }
}