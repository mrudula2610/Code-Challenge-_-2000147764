show databases;

CREATE DATABASE PetPlatform;
use PetPlatform;

-- Pet Table
CREATE TABLE Pet (
    id INT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    age INT NOT NULL,
    breed VARCHAR(255) NOT NULL,
    adopted BOOLEAN DEFAULT false
);


-- Dog Table (Inherits from Pet)
CREATE TABLE Dog (
    pet_id INT PRIMARY KEY,
    dog_breed VARCHAR(255) NOT NULL,
    FOREIGN KEY (pet_id) REFERENCES Pet(id)
);

-- Cat Table (Inherits from Pet)
CREATE TABLE Cat (
    pet_id INT PRIMARY KEY,
    cat_color VARCHAR(255) NOT NULL,
    FOREIGN KEY (pet_id) REFERENCES Pet(id)
);

-- PetShelter Table
CREATE TABLE PetShelter (
    pet_id INT PRIMARY KEY,
    FOREIGN KEY (pet_id) REFERENCES Pet(id)
);

-- Donation Table (Abstract)
CREATE TABLE Donation (
    id INT PRIMARY KEY,
    donor_name VARCHAR(255) NOT NULL,
    amount DECIMAL(10, 2) NOT NULL
);

-- CashDonation Table (Derived from Donation)
CREATE TABLE CashDonation (
    donation_id INT PRIMARY KEY,
    donation_date DATE NOT NULL,
    FOREIGN KEY (donation_id) REFERENCES Donation(id)
);

-- ItemDonation Table (Derived from Donation)
CREATE TABLE ItemDonation (
    donation_id INT PRIMARY KEY,
    item_type VARCHAR(255) NOT NULL,
    FOREIGN KEY (donation_id) REFERENCES Donation(id)
);
CREATE TABLE adoption_events (
    event_id INT AUTO_INCREMENT PRIMARY KEY,
    event_name VARCHAR(255) NOT NULL,
    event_date DATE NOT NULL
);
CREATE TABLE participants (
    participant_id INT AUTO_INCREMENT PRIMARY KEY,
    participant_name VARCHAR(255) NOT NULL,
    event_id INT,
    FOREIGN KEY (event_id) REFERENCES adoption_events(event_id)
);



INSERT INTO Pet (id, name, age, breed, adopted) VALUES
(1, 'Buddy', 3, 'Golden Retriever', false),
(2, 'Mittens', 2, 'Siamese', true),
(3, 'Charlie', 4, 'Beagle', false),
(4, 'Whiskers', 1, 'Persian', true),
(5, 'Max', 5, 'Labrador', false),
(6, 'Bella', 2, 'Bulldog', false),
(7, 'Oliver', 3, 'Tabby', true),
(8, 'Lucy', 4, 'Sphynx', false),
(9, 'Daisy', 1, 'Maine Coon', true),
(10, 'Rocky', 6, 'Rottweiler', false);

INSERT INTO Dog (pet_id, dog_breed) VALUES
(1, 'Golden Retriever'),
(3, 'Beagle'),
(5, 'Labrador'),
(6, 'Bulldog'),
(10, 'Rottweiler');

INSERT INTO Cat (pet_id, cat_color) VALUES
(2, 'Cream'),
(4, 'White'),
(7, 'Orange Tabby'),
(8, 'Gray'),
(9, 'Black');

INSERT INTO PetShelter (pet_id) VALUES
(1),  -- Buddy
(2),  -- Mittens
(3),  -- Charlie
(4),  -- Whiskers
(5),  -- Max
(6),  -- Bella
(7),  -- Oliver
(8),  -- Lucy
(9),  -- Daisy
(10); -- Rocky

INSERT INTO Donation (id, donor_name, amount) VALUES
(1, 'John Doe', 100.00),
(2, 'Jane Smith', 250.50),
(3, 'Alice Johnson', 75.00),
(4, 'Bob Brown', 200.00),
(5, 'Charlie Davis', 150.75),
(6, 'Tom Hanks', 300.00),
(7, 'Emma Watson', 50.00),
(8, 'Chris Evans', 125.00),
(9, 'Scarlett Johansson', 175.00),
(10, 'Robert Downey Jr.', 400.00);

INSERT INTO CashDonation (donation_id, donation_date) VALUES
(1, '2023-01-15'),
(2, '2023-02-20'),
(3, '2023-03-10'),
(4, '2023-04-05'),
(5, '2023-05-25'),
(6, '2023-06-01'),
(7, '2023-07-15'),
(8, '2023-08-20'),
(9, '2023-09-10'),
(10, '2023-10-01');

INSERT INTO ItemDonation (donation_id, item_type) VALUES
(1, 'Dog Food'),
(2, 'Cat Toys'),
(3, 'Blankets'),
(4, 'Leashes'),
(5, 'Cat Litter'),
(6, 'Pet Beds'),
(7, 'Food Bowls'),
(8, 'Toys'),
(9, 'Grooming Supplies'),
(10, 'Treats');

INSERT INTO adoption_events (event_name, event_date) VALUES
('Adoption Day', '2023-06-01'),
('Pet Fair', '2023-07-15'),
('Fundraising Gala', '2023-08-20'),
('Volunteer Day', '2023-09-10'),
('Spring Adoption Fair', '2023-11-01'),
('Holiday Fundraiser', '2023-12-15');

INSERT INTO participants (participant_name, event_id) VALUES
('Emily Clark', 1),  -- Participated in Adoption Day
('Michael Green', 2),  -- Participated in Pet Fair
('Sarah White', 3),  -- Participated in Fundraising Gala
('David Black', 4),  -- Participated in Volunteer Day
('Laura Blue', 5),  -- Participated in Spring Adoption Fair
('Anna Kendrick', 6),  -- Participated in Holiday Fundraiser
('Ryan Gosling', 1),  -- Participated in Adoption Day
('Tom Hanks', 2),  -- Participated in Pet Fair
('Emma Watson', 3),  -- Participated in Fundraising Gala
('Chris Evans', 4),  -- Participated in Volunteer Day
('Scarlett Johansson', 5),  -- Participated in Spring Adoption Fair
('Robert Downey Jr.', 6),  -- Participated in Holiday Fundraiser
('Natalie Portman', 1),  -- Participated in Adoption Day
('Hugh Jackman', 2),  -- Participated in Pet Fair
('Jennifer Lawrence', 3),  -- Participated in Fundraising Gala
('Chris Hemsworth', 4),  -- Participated in Volunteer Day
('Gal Gadot', 5);  -- Participated in Spring Adoption Fair

show tables;
desc adoption_events;
desc cashdonation;
desc cat;
desc dog;
desc donation;
desc itemdonation;
desc participants;
desc pet;
desc petshelter;

SELECT * FROM adoption_events;
SELECT * FROM cashdonation;
SELECT * FROM cat;
SELECT * FROM donation;
SELECT * FROM itemdonation;
SELECT * FROM participants;
SELECT * FROM pet;
SELECT * FROM petshelter;


