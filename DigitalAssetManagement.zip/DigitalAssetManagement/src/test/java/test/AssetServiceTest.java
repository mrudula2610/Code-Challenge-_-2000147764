package test;

import org.example.entity.Asset;
import exception.AssetNotFoundException;
import exception.AssetNotMaintainException;
import org.junit.Before;
import org.junit.Test;
import service.AssetService;
import service.AssetServiceImpl;

import java.util.Date;

import static org.junit.Assert.*;

public class AssetServiceTest {
    private AssetService service;

    @Before
    public void setUp() {
        service = new AssetServiceImpl();
    }

    @Test
    public void testAssetCreatedSuccessfully() throws AssetNotFoundException {
        Asset asset = new Asset(0, "Test Laptop", "Electronics", "SN999", new Date(), "Office", "In Use", 1);
        assertTrue("Asset should be added successfully", service.addAsset(asset));
    }

    @Test
    public void testAssetMaintenanceSuccessfully() throws AssetNotFoundException, AssetNotMaintainException {
        assertTrue("Maintenance should be recorded successfully",
                service.performMaintenance(1, "2025-04-07", "Test maintenance", 50.0));
    }

    @Test
    public void testAssetReservedSuccessfully() throws AssetNotFoundException {
        assertTrue("Reservation should be successful",
                service.reserveAsset(2, 2, "2025-04-07", "2025-04-08", "2025-04-10"));
    }

    @Test(expected = AssetNotFoundException.class)
    public void testAssetNotFoundException() throws AssetNotFoundException {
        service.deleteAsset(999); // Non-existent ID
    }
}