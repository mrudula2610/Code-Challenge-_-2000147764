package dao;

import org.example.entity.Asset;

import java.sql.SQLException;

public interface AssetDAO {
    boolean addAsset(Asset asset) throws SQLException;
    boolean updateAsset(Asset asset) throws SQLException;
    boolean deleteAsset(int assetId) throws SQLException;
    boolean allocateAsset(int assetId, int employeeId, String allocationDate) throws SQLException;
    boolean deallocateAsset(int assetId, int employeeId, String returnDate) throws SQLException;
    boolean performMaintenance(int assetId, String maintenanceDate, String description, double cost) throws SQLException;
    boolean reserveAsset(int assetId, int employeeId, String reservationDate, String startDate, String endDate) throws SQLException;
    boolean withdrawReservation(int reservationId) throws SQLException;
    java.util.Date getLastMaintenanceDate(int assetId) throws SQLException; // Helper method for service layer
    boolean assetExists(int assetId) throws SQLException; // Helper method
}