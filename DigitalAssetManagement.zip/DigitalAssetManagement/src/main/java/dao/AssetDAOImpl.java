package dao;

import org.example.entity.Asset;
import util.DBConnUtil;

import java.sql.*;
import java.util.Date;

public class AssetDAOImpl implements AssetDAO {
    private Connection conn;

    public AssetDAOImpl() {
        String connString = util.DBPropertyUtil.getConnectionString("db.properties");
        this.conn = DBConnUtil.getConnection(connString);
    }

    @Override
    public boolean addAsset(Asset asset) throws SQLException {
        String sql = "INSERT INTO assets (name, type, serial_number, purchase_date, location, status, owner_id) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, asset.getName());
            ps.setString(2, asset.getType());
            ps.setString(3, asset.getSerialNumber());
            ps.setDate(4, new java.sql.Date(asset.getPurchaseDate().getTime()));
            ps.setString(5, asset.getLocation());
            ps.setString(6, asset.getStatus());
            ps.setInt(7, asset.getOwnerId());
            return ps.executeUpdate() > 0;
        }
    }

    @Override
    public boolean updateAsset(Asset asset) throws SQLException {
        String sql = "UPDATE assets SET name=?, type=?, serial_number=?, purchase_date=?, location=?, status=?, owner_id=? " +
                "WHERE asset_id=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, asset.getName());
            ps.setString(2, asset.getType());
            ps.setString(3, asset.getSerialNumber());
            ps.setDate(4, new java.sql.Date(asset.getPurchaseDate().getTime()));
            ps.setString(5, asset.getLocation());
            ps.setString(6, asset.getStatus());
            ps.setInt(7, asset.getOwnerId());
            ps.setInt(8, asset.getAssetId());
            return ps.executeUpdate() > 0;
        }
    }

    @Override
    public boolean deleteAsset(int assetId) throws SQLException {
        String sql = "DELETE FROM assets WHERE asset_id=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, assetId);
            return ps.executeUpdate() > 0;
        }
    }

    @Override
    public boolean allocateAsset(int assetId, int employeeId, String allocationDate) throws SQLException {
        String sql = "INSERT INTO asset_allocations (asset_id, employee_id, allocation_date) VALUES (?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, assetId);
            ps.setInt(2, employeeId);
            ps.setDate(3, java.sql.Date.valueOf(allocationDate));
            return ps.executeUpdate() > 0;
        }
    }

    @Override
    public boolean deallocateAsset(int assetId, int employeeId, String returnDate) throws SQLException {
        String sql = "UPDATE asset_allocations SET return_date=? WHERE asset_id=? AND employee_id=? AND return_date IS NULL";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, java.sql.Date.valueOf(returnDate));
            ps.setInt(2, assetId);
            ps.setInt(3, employeeId);
            return ps.executeUpdate() > 0;
        }
    }

    @Override
    public boolean performMaintenance(int assetId, String maintenanceDate, String description, double cost) throws SQLException {
        String sql = "INSERT INTO maintenance_records (asset_id, maintenance_date, description, cost) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, assetId);
            ps.setDate(2, java.sql.Date.valueOf(maintenanceDate));
            ps.setString(3, description);
            ps.setDouble(4, cost);
            return ps.executeUpdate() > 0;
        }
    }

    @Override
    public boolean reserveAsset(int assetId, int employeeId, String reservationDate, String startDate, String endDate) throws SQLException {
        String sql = "INSERT INTO reservations (asset_id, employee_id, reservation_date, start_date, end_date, status) " +
                "VALUES (?, ?, ?, ?, ?, 'Pending')";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, assetId);
            ps.setInt(2, employeeId);
            ps.setDate(3, java.sql.Date.valueOf(reservationDate));
            ps.setDate(4, java.sql.Date.valueOf(startDate));
            ps.setDate(5, java.sql.Date.valueOf(endDate));
            return ps.executeUpdate() > 0;
        }
    }

    @Override
    public boolean withdrawReservation(int reservationId) throws SQLException {
        String sql = "DELETE FROM reservations WHERE reservation_id=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, reservationId);
            return ps.executeUpdate() > 0;
        }
    }

    @Override
    public Date getLastMaintenanceDate(int assetId) throws SQLException {
        String sql = "SELECT maintenance_date FROM maintenance_records WHERE asset_id=? ORDER BY maintenance_date DESC LIMIT 1";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, assetId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getDate("maintenance_date");
            }
            return null;
        }
    }

    @Override
    public boolean assetExists(int assetId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM assets WHERE asset_id=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, assetId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            return false;
        }
    }
}