package service;

import org.example.entity.Asset;
import exception.AssetNotFoundException;
import exception.AssetNotMaintainException;

public interface AssetService {
    boolean addAsset(Asset asset) throws AssetNotFoundException;
    boolean updateAsset(Asset asset) throws AssetNotFoundException;
    boolean deleteAsset(int assetId) throws AssetNotFoundException;
    boolean allocateAsset(int assetId, int employeeId, String allocationDate) throws AssetNotFoundException;
    boolean deallocateAsset(int assetId, int employeeId, String returnDate) throws AssetNotFoundException;
    boolean performMaintenance(int assetId, String maintenanceDate, String description, double cost)
            throws AssetNotFoundException, AssetNotMaintainException;
    boolean reserveAsset(int assetId, int employeeId, String reservationDate, String startDate, String endDate)
            throws AssetNotFoundException;
    boolean withdrawReservation(int reservationId) throws AssetNotFoundException;
}