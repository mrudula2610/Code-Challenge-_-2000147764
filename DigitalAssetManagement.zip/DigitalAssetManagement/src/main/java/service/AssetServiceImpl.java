package service;

import dao.AssetDAO;
import dao.AssetDAOImpl;
import org.example.entity.Asset;
import exception.AssetNotFoundException;
import exception.AssetNotMaintainException;

import java.sql.SQLException;
import java.util.Date;

public class AssetServiceImpl implements AssetService {
    private final AssetDAO assetDAO;

    public AssetServiceImpl() {
        this.assetDAO = new AssetDAOImpl();
    }

    @Override
    public boolean addAsset(Asset asset) throws AssetNotFoundException {
        try {
            return assetDAO.addAsset(asset);
        } catch (SQLException e) {
            throw new AssetNotFoundException("Failed to add asset due to database error: " + e.getMessage());
        }
    }

    @Override
    public boolean updateAsset(Asset asset) throws AssetNotFoundException {
        try {
            if (!assetDAO.assetExists(asset.getAssetId())) {
                throw new AssetNotFoundException("Asset ID " + asset.getAssetId() + " not found.");
            }
            return assetDAO.updateAsset(asset);
        } catch (SQLException e) {
            throw new AssetNotFoundException("Failed to update asset: " + e.getMessage());
        }
    }

    @Override
    public boolean deleteAsset(int assetId) throws AssetNotFoundException {
        try {
            if (!assetDAO.assetExists(assetId)) {
                throw new AssetNotFoundException("Asset ID " + assetId + " not found.");
            }
            return assetDAO.deleteAsset(assetId);
        } catch (SQLException e) {
            throw new AssetNotFoundException("Failed to delete asset: " + e.getMessage());
        }
    }

    @Override
    public boolean allocateAsset(int assetId, int employeeId, String allocationDate) throws AssetNotFoundException {
        try {
            if (!assetDAO.assetExists(assetId)) {
                throw new AssetNotFoundException("Asset ID " + assetId + " not found.");
            }
            return assetDAO.allocateAsset(assetId, employeeId, allocationDate);
        } catch (SQLException e) {
            throw new AssetNotFoundException("Failed to allocate asset: " + e.getMessage());
        }
    }

    @Override
    public boolean deallocateAsset(int assetId, int employeeId, String returnDate) throws AssetNotFoundException {
        try {
            if (!assetDAO.assetExists(assetId)) {
                throw new AssetNotFoundException("Asset ID " + assetId + " not found.");
            }
            boolean success = assetDAO.deallocateAsset(assetId, employeeId, returnDate);
            if (!success) {
                throw new AssetNotFoundException("No active allocation found for Asset ID " + assetId + " and Employee ID " + employeeId);
            }
            return true;
        } catch (SQLException e) {
            throw new AssetNotFoundException("Failed to deallocate asset: " + e.getMessage());
        }
    }

    @Override
    public boolean performMaintenance(int assetId, String maintenanceDate, String description, double cost)
            throws AssetNotFoundException, AssetNotMaintainException {
        try {
            if (!assetDAO.assetExists(assetId)) {
                throw new AssetNotFoundException("Asset ID " + assetId + " not found.");
            }
            Date lastMaintenance = assetDAO.getLastMaintenanceDate(assetId);
            if (lastMaintenance != null) {
                long diff = new Date().getTime() - lastMaintenance.getTime();
                if (diff > 2 * 365 * 24 * 60 * 60 * 1000L) { // 2 years in milliseconds
                    throw new AssetNotMaintainException("Asset ID " + assetId + " not maintained for over 2 years.");
                }
            }
            return assetDAO.performMaintenance(assetId, maintenanceDate, description, cost);
        } catch (SQLException e) {
            throw new AssetNotFoundException("Failed to perform maintenance: " + e.getMessage());
        }
    }

    @Override
    public boolean reserveAsset(int assetId, int employeeId, String reservationDate, String startDate, String endDate)
            throws AssetNotFoundException {
        try {
            if (!assetDAO.assetExists(assetId)) {
                throw new AssetNotFoundException("Asset ID " + assetId + " not found.");
            }
            return assetDAO.reserveAsset(assetId, employeeId, reservationDate, startDate, endDate);
        } catch (SQLException e) {
            throw new AssetNotFoundException("Failed to reserve asset: " + e.getMessage());
        }
    }

    @Override
    public boolean withdrawReservation(int reservationId) throws AssetNotFoundException {
        try {
            boolean success = assetDAO.withdrawReservation(reservationId);
            if (!success) {
                throw new AssetNotFoundException("Reservation ID " + reservationId + " not found.");
            }
            return true;
        } catch (SQLException e) {
            throw new AssetNotFoundException("Failed to withdraw reservation: " + e.getMessage());
        }
    }
}