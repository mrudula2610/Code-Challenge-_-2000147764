package util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class DBPropertyUtil {
    public static String getConnectionString(String propertyFileName) {
        Properties props = new Properties();
        try (InputStream is = DBPropertyUtil.class.getClassLoader().getResourceAsStream(propertyFileName)) {
            if (is == null) throw new IOException("Property file not found: " + propertyFileName);
            props.load(is);
            return props.getProperty("db.url") + "?user=" + props.getProperty("db.user") +
                    "&password=" + props.getProperty("db.password");
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
