package main;

import org.example.entity.Asset;
import exception.AssetNotFoundException;
import exception.AssetNotMaintainException;
import service.AssetService;
import service.AssetServiceImpl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class AssetManagementApp {
    public static void main(String[] args) {
        AssetService service = new AssetServiceImpl();
        Scanner sc = new Scanner(System.in);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        while (true) {
            System.out.println("\n--- Digital Asset Management System ---");
            System.out.println("1. Add Asset");
            System.out.println("2. Update Asset");
            System.out.println("3. Delete Asset");
            System.out.println("4. Allocate Asset");
            System.out.println("5. Deallocate Asset");
            System.out.println("6. Perform Maintenance");
            System.out.println("7. Reserve Asset");
            System.out.println("8. Withdraw Reservation");
            System.out.println("9. Exit");
            System.out.print("Choose an option: ");
            int choice = sc.nextInt();
            sc.nextLine(); // Consume newline

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter asset name: ");
                        String name = sc.nextLine();
                        System.out.print("Enter asset type: ");
                        String type = sc.nextLine();
                        System.out.print("Enter serial number: ");
                        String serial = sc.nextLine();
                        System.out.print("Enter purchase date (YYYY-MM-DD): ");
                        Date purchaseDate = sdf.parse(sc.nextLine());
                        System.out.print("Enter location: ");
                        String location = sc.nextLine();
                        System.out.print("Enter status: ");
                        String status = sc.nextLine();
                        System.out.print("Enter owner ID: ");
                        int ownerId = sc.nextInt();
                        Asset asset = new Asset(0, name, type, serial, purchaseDate, location, status, ownerId);
                        System.out.println(service.addAsset(asset) ? "Asset added!" : "Failed to add asset.");
                        break;

                    case 2:
                        System.out.print("Enter asset ID: ");
                        int updateId = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter new asset name: ");
                        String updateName = sc.nextLine();
                        System.out.print("Enter new type: ");
                        String updateType = sc.nextLine();
                        System.out.print("Enter new serial number: ");
                        String updateSerial = sc.nextLine();
                        System.out.print("Enter new purchase date (YYYY-MM-DD): ");
                        Date updatePurchaseDate = sdf.parse(sc.nextLine());
                        System.out.print("Enter new location: ");
                        String updateLocation = sc.nextLine();
                        System.out.print("Enter new status: ");
                        String updateStatus = sc.nextLine();
                        System.out.print("Enter new owner ID: ");
                        int updateOwnerId = sc.nextInt();
                        Asset updateAsset = new Asset(updateId, updateName, updateType, updateSerial,
                                updatePurchaseDate, updateLocation, updateStatus, updateOwnerId);
                        System.out.println(service.updateAsset(updateAsset) ? "Asset updated!" : "Failed to update.");
                        break;

                    case 3:
                        System.out.print("Enter asset ID: ");
                        int deleteId = sc.nextInt();
                        System.out.println(service.deleteAsset(deleteId) ? "Asset deleted!" : "Failed to delete.");
                        break;

                    case 4:
                        System.out.print("Enter asset ID: ");
                        int allocAssetId = sc.nextInt();
                        System.out.print("Enter employee ID: ");
                        int allocEmpId = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter allocation date (YYYY-MM-DD): ");
                        String allocDate = sc.nextLine();
                        System.out.println(service.allocateAsset(allocAssetId, allocEmpId, allocDate)
                                ? "Asset allocated!" : "Failed to allocate.");
                        break;

                    case 5:
                        System.out.print("Enter asset ID: ");
                        int deallocAssetId = sc.nextInt();
                        System.out.print("Enter employee ID: ");
                        int deallocEmpId = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter return date (YYYY-MM-DD): ");
                        String returnDate = sc.nextLine();
                        System.out.println(service.deallocateAsset(deallocAssetId, deallocEmpId, returnDate)
                                ? "Asset deallocated!" : "Failed to deallocate.");
                        break;

                    case 6:
                        System.out.print("Enter asset ID: ");
                        int maintId = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter maintenance date (YYYY-MM-DD): ");
                        String maintDate = sc.nextLine();
                        System.out.print("Enter description: ");
                        String desc = sc.nextLine();
                        System.out.print("Enter cost: ");
                        double cost = sc.nextDouble();
                        System.out.println(service.performMaintenance(maintId, maintDate, desc, cost)
                                ? "Maintenance recorded!" : "Failed to record maintenance.");
                        break;

                    case 7:
                        System.out.print("Enter asset ID: ");
                        int resAssetId = sc.nextInt();
                        System.out.print("Enter employee ID: ");
                        int resEmpId = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter reservation date (YYYY-MM-DD): ");
                        String resDate = sc.nextLine();
                        System.out.print("Enter start date (YYYY-MM-DD): ");
                        String startDate = sc.nextLine();
                        System.out.print("Enter end date (YYYY-MM-DD): ");
                        String endDate = sc.nextLine();
                        System.out.println(service.reserveAsset(resAssetId, resEmpId, resDate, startDate, endDate)
                                ? "Asset reserved!" : "Failed to reserve.");
                        break;

                    case 8:
                        System.out.print("Enter reservation ID: ");
                        int resId = sc.nextInt();
                        System.out.println(service.withdrawReservation(resId)
                                ? "Reservation withdrawn!" : "Failed to withdraw.");
                        break;

                    case 9:
                        System.out.println("Exiting...");
                        sc.close();
                        return;

                    default:
                        System.out.println("Invalid option.");
                }
            } catch (AssetNotFoundException | AssetNotMaintainException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Unexpected error: " + e.getMessage());
            }
        }
    }
}