-- Task 1.1: Create the TechShop database
CREATE DATABASE TechShop;
USE TechShop;

-- Task 1.2: Create Customers table
CREATE TABLE Customers (
                           CustomerID INT PRIMARY KEY AUTO_INCREMENT,
                           FirstName VARCHAR(50),
                           LastName VARCHAR(50),
                           Email VARCHAR(100),
                           Phone VARCHAR(20),
                           Address TEXT
);

-- Create Products table
CREATE TABLE Products (
                          ProductID INT PRIMARY KEY AUTO_INCREMENT,
                          ProductName VARCHAR(100),
                          Description TEXT,
                          Price DECIMAL(10, 2)
);

-- Create Orders table with FK to Customers
CREATE TABLE Orders (
                        OrderID INT PRIMARY KEY AUTO_INCREMENT,
                        CustomerID INT,
                        OrderDate DATE,
                        TotalAmount DECIMAL(10, 2),
                        FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

-- Create OrderDetails table with FK to Orders & Products
CREATE TABLE OrderDetails (
                              OrderDetailID INT PRIMARY KEY AUTO_INCREMENT,
                              OrderID INT,
                              ProductID INT,
                              Quantity INT,
                              FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
                              FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
);

-- Create Inventory table with FK to Products
CREATE TABLE Inventory (
                           InventoryID INT PRIMARY KEY AUTO_INCREMENT,
                           ProductID INT,
                           QuantityInStock INT,
                           LastStockUpdate DATE,
                           FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
);

-- Inserting 10 sample customers
INSERT INTO Customers (CustomerID, FirstName, LastName, Email, Phone, Address) VALUES
                                                                                   (1, 'Alice', 'Johnson', 'alice.johnson@example.com', '9991112221', '123 Park Ave'),
                                                                                   (2, 'Bob', 'Smith', 'bob.smith@example.com', '9991112222', '456 Main St'),
                                                                                   (3, 'Carol', 'Taylor', 'carol.taylor@example.com', '9991112223', '789 Oak Blvd'),
                                                                                   (4, 'David', 'Lee', 'david.lee@example.com', '9991112224', '321 Elm St'),
                                                                                   (5, 'Eva', 'Martinez', 'eva.martinez@example.com', '9991112225', '654 Pine St'),
                                                                                   (6, 'Frank', 'Brown', 'frank.brown@example.com', '9991112226', '987 Maple Dr'),
                                                                                   (7, 'Grace', 'Wilson', 'grace.wilson@example.com', '9991112227', '741 Cedar Ave'),
                                                                                   (8, 'Henry', 'Davis', 'henry.davis@example.com', '9991112228', '852 Birch Ln'),
                                                                                   (9, 'Ivy', 'Clark', 'ivy.clark@example.com', '9991112229', '963 Spruce Blvd'),
                                                                                   (10, 'Jack', 'Walker', 'jack.walker@example.com', '9991112230', '147 Aspen Ct');

-- Inserting 10 sample products
INSERT INTO Products (ProductID, ProductName, Description, Price) VALUES
                                                                      (1, 'Wireless Mouse', 'Ergonomic Bluetooth mouse', 899.00),
                                                                      (2, 'Mechanical Keyboard', 'RGB backlit keyboard', 2499.00),
                                                                      (3, 'HD Monitor', '24-inch full HD monitor', 9999.00),
                                                                      (4, 'USB-C Charger', 'Fast charging adapter', 1299.00),
                                                                      (5, 'Bluetooth Speaker', 'Portable speaker with deep bass', 1999.00),
                                                                      (6, 'Gaming Headset', 'Surround sound headset', 3499.00),
                                                                      (7, 'Laptop Stand', 'Adjustable aluminum stand', 1199.00),
                                                                      (8, 'Webcam', '1080p USB webcam', 1599.00),
                                                                      (9, 'External SSD', '500GB portable SSD', 3999.00),
                                                                      (10, 'Smartwatch', 'Fitness tracker with notifications', 4999.00);

-- Inserting 10 sample orders
INSERT INTO Orders (OrderID, CustomerID, OrderDate, TotalAmount) VALUES
                                                                     (101, 1, '2025-04-01', 4998.00),
                                                                     (102, 2, '2025-04-02', 899.00),
                                                                     (103, 3, '2025-04-03', 1999.00),
                                                                     (104, 4, '2025-04-03', 2499.00),
                                                                     (105, 5, '2025-04-04', 9999.00),
                                                                     (106, 6, '2025-04-04', 3798.00),
                                                                     (107, 7, '2025-04-05', 1299.00),
                                                                     (108, 8, '2025-04-05', 1199.00),
                                                                     (109, 9, '2025-04-06', 1599.00),
                                                                     (110, 10, '2025-04-06', 4999.00);

-- Inserting 10 sample order details
INSERT INTO OrderDetails (OrderDetailID, OrderID, ProductID, Quantity) VALUES
                                                                           (1, 101, 2, 2),
                                                                           (2, 102, 1, 1),
                                                                           (3, 103, 5, 1),
                                                                           (4, 104, 2, 1),
                                                                           (5, 105, 3, 1),
                                                                           (6, 106, 6, 1),
                                                                           (7, 106, 4, 1),
                                                                           (8, 107, 4, 1),
                                                                           (9, 108, 7, 1),
                                                                           (10, 109, 8, 1);

-- Inserting 10 sample inventory records
INSERT INTO Inventory (InventoryID, ProductID, QuantityInStock, LastStockUpdate) VALUES
                                                                                     (1, 1, 30, '2025-04-01'),
                                                                                     (2, 2, 50, '2025-04-01'),
                                                                                     (3, 3, 20, '2025-04-01'),
                                                                                     (4, 4, 40, '2025-04-01'),
                                                                                     (5, 5, 35, '2025-04-01'),
                                                                                     (6, 6, 25, '2025-04-01'),
                                                                                     (7, 7, 60, '2025-04-01'),
                                                                                     (8, 8, 45, '2025-04-01'),
                                                                                     (9, 9, 15, '2025-04-01'),
                                                                                     (10, 10, 10, '2025-04-01');



-- Task 2.1: Retrieve names and emails of all customers
SELECT FirstName, LastName, Email FROM Customers;

-- Task 2.2: List all orders with order dates and customer names
SELECT o.OrderID, o.OrderDate, c.FirstName, c.LastName
FROM Orders o
         JOIN Customers c ON o.CustomerID = c.CustomerID;

-- Task 2.3: Insert new customer
INSERT INTO Customers (FirstName, LastName, Email, Phone, Address)
VALUES ('Riya', 'Khan', 'riya.khan@example.com', '9988776655', '555 Mango Lane');

-- Task 2.4: Increase prices of all products by 10%
set sql_safe_updates=0;
UPDATE Products
SET Price = Price * 1.10;

-- Task 2.5: Delete a specific order and its order details (OrderID = ?)
DELETE FROM OrderDetails WHERE OrderID = 104;
DELETE FROM Orders WHERE OrderID = 104;

-- Task 2.6: Insert new order for a customer
INSERT INTO Customers (CustomerID, FirstName, LastName, Email, Phone, Address)
VALUES (12, 'John', 'Doe', 'john.doe@example.com', '9876543210', '123 Main St, TechCity');

INSERT INTO Orders (CustomerID, OrderDate, TotalAmount)
VALUES (11, CURDATE(), 5004);



-- Task 2.7: Update contact info for a customer
UPDATE Customers
SET Email = 'alic.mane@example.com', Address = '123 Park Shirol'
WHERE CustomerID = 1;

-- Task 2.8: Recalculate total cost of each order
UPDATE Orders o
    JOIN (
    SELECT od.OrderID, SUM(p.Price * od.Quantity) AS Total
    FROM OrderDetails od
    JOIN Products p ON od.ProductID = p.ProductID
    GROUP BY od.OrderID
    ) t ON o.OrderID = t.OrderID
    SET o.TotalAmount = t.Total;

-- Task 2.9: Delete all orders and order details for a customer
DELETE FROM OrderDetails WHERE OrderID IN (
    SELECT OrderID FROM Orders WHERE CustomerID = 4
);
DELETE FROM Orders WHERE CustomerID = 4;

-- Task 2.10: Insert a new electronic gadget product
INSERT INTO Products (ProductName, Description, Price)
VALUES ('Bluetooth Speaker', 'Portable Bluetooth Speaker', 1999.00);

-- Task 2.11: Update status of a specific order (Assuming Status column exists)
-- Add Status column first if not exists
ALTER TABLE Orders ADD COLUMN Status VARCHAR(20) DEFAULT 'Pending';
UPDATE Orders
SET Status = 'suceess'
WHERE OrderID = 105;
select * from customers;
select * from orders;
select* from orderdetails;
select* from inventory;

-- Task 2.12: Update number of orders placed by each customer
-- Add OrderCount column first if not exists
ALTER TABLE Customers ADD COLUMN OrderCount INT DEFAULT 0;

UPDATE Customers c
    JOIN (
    SELECT CustomerID, COUNT(*) AS OrderTotal
    FROM Orders
    GROUP BY CustomerID
    ) o ON c.CustomerID = o.CustomerID
    SET c.OrderCount = o.OrderTotal;


-- Task 3.1: Retrieve all orders with customer information
SELECT o.OrderID, o.OrderDate, o.TotalAmount, c.FirstName, c.LastName
FROM Orders o
         JOIN Customers c ON o.CustomerID = c.CustomerID;

-- Task 3.2: Total revenue generated by each product
SELECT p.ProductName, SUM(p.Price * od.Quantity) AS TotalRevenue
FROM OrderDetails od
         JOIN Products p ON od.ProductID = p.ProductID
GROUP BY p.ProductName;

-- Task 3.3: List customers who made at least one purchase
SELECT DISTINCT c.CustomerID, c.FirstName, c.LastName, c.Email, c.Phone
FROM Customers c
         JOIN Orders o ON c.CustomerID = o.CustomerID;

-- Task 3.4: Most popular product by quantity ordered
SELECT p.ProductName, SUM(od.Quantity) AS TotalQuantity
FROM OrderDetails od
         JOIN Products p ON od.ProductID = p.ProductID
GROUP BY p.ProductName
ORDER BY TotalQuantity DESC
    LIMIT 1;

-- Task 3.5: List of products and their categories
-- (Assumes category column exists, add if needed)
ALTER TABLE Products ADD COLUMN Category VARCHAR(50);
SELECT ProductName, Category FROM Products;

-- Task 3.6: Average order value per customer
SELECT c.CustomerID, c.FirstName, c.LastName, AVG(o.TotalAmount) AS AvgOrderValue
FROM Orders o
         JOIN Customers c ON o.CustomerID = c.CustomerID
GROUP BY c.CustomerID;

-- Task 3.7: Order with highest revenue
SELECT o.OrderID, o.TotalAmount, c.FirstName, c.LastName
FROM Orders o
         JOIN Customers c ON o.CustomerID = c.CustomerID
ORDER BY o.TotalAmount DESC
    LIMIT 1;

-- Task 3.8: Products with number of times ordered
SELECT p.ProductName, COUNT(od.OrderDetailID) AS TimesOrdered
FROM OrderDetails od
         JOIN Products p ON od.ProductID = p.ProductID
GROUP BY p.ProductName;

-- Task 3.9: Customers who purchased a specific product (by name)
SELECT DISTINCT c.CustomerID, c.FirstName, c.LastName
FROM Customers c
         JOIN Orders o ON c.CustomerID = o.CustomerID
         JOIN OrderDetails od ON o.OrderID = od.OrderID
         JOIN Products p ON od.ProductID = p.ProductID
WHERE p.ProductName = 'HD monitor';


-- Task 3.10: Total revenue in a specific date range
SELECT SUM(TotalAmount) AS TotalRevenue
FROM Orders
WHERE OrderDate BETWEEN '2025-04-01' AND '2025-04-02';



-- Task 4.1: Customers who haven't placed any orders
SELECT * FROM Customers
WHERE CustomerID NOT IN (SELECT DISTINCT CustomerID FROM Orders);

-- Task 4.2: Total number of products available
SELECT COUNT(*) AS TotalProducts FROM Products;

-- Task 4.3: Total revenue of TechShop
SELECT SUM(TotalAmount) AS TotalRevenue FROM Orders;

-- Task 4.4: Average quantity ordered for products in a category
SELECT AVG(od.Quantity) AS AvgQuantity
FROM OrderDetails od
         JOIN Products p ON od.ProductID = p.ProductID
WHERE p.Category = null;


-- Task 4.5: Revenue generated by a specific customer
SELECT c.CustomerID, c.FirstName, c.LastName, SUM(o.TotalAmount) AS TotalSpent
FROM Customers c
         JOIN Orders o ON c.CustomerID = o.CustomerID
WHERE c.CustomerID = 4
GROUP BY c.CustomerID;


-- Task 4.6: Customers who placed the most orders
SELECT c.CustomerID, c.FirstName, c.LastName, COUNT(o.OrderID) AS OrderCount
FROM Customers c
         JOIN Orders o ON c.CustomerID = o.CustomerID
GROUP BY c.CustomerID
ORDER BY OrderCount DESC
    LIMIT 1;

-- Task 4.7: Most popular product category (by total quantity ordered)
SELECT p.Category, SUM(od.Quantity) AS TotalQuantity
FROM OrderDetails od
         JOIN Products p ON od.ProductID = p.ProductID
GROUP BY p.Category
ORDER BY TotalQuantity DESC
    LIMIT 1;

-- Task 4.8: Customer who spent the most
SELECT c.CustomerID, c.FirstName, c.LastName, SUM(o.TotalAmount) AS TotalSpent
FROM Customers c
         JOIN Orders o ON c.CustomerID = o.CustomerID
GROUP BY c.CustomerID
ORDER BY TotalSpent DESC
    LIMIT 1;

-- Task 4.9: Average order value for all customers
SELECT AVG(TotalAmount) AS AvgOrderValue FROM Orders;

-- Task 4.10: Total number of orders by each customer
SELECT c.CustomerID, c.FirstName, c.LastName, COUNT(o.OrderID) AS TotalOrders
FROM Customers c
         LEFT JOIN Orders o ON c.CustomerID = o.CustomerID
GROUP BY c.CustomerID;
