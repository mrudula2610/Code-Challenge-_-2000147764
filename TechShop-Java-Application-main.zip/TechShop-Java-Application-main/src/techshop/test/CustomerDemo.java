package techshop.test;

import techshop.model.Customer;
import techshop.exception.InvalidDataException;

public class CustomerDemo {
    public static void main(String[] args) {
        // Create a customer with valid data
        Customer customer = new Customer(101, "Alice", "Smith", "alice@example.com", "9876543210", "Bangalore");

        try {
            // Try updating with an invalid email (no '@')
            customer.updateCustomerInfo("invalidemail", "9876543210", "Chennai");
        } catch (InvalidDataException e) {
            System.out.println("Caught Exception: " + e.getMessage());
        }

        // Try with valid email
        try {
            customer.updateCustomerInfo("alice.new@example.com", "9876543210", "Hyderabad");
            System.out.println("Customer info updated successfully.");
        } catch (InvalidDataException e) {
            System.out.println("Caught Exception: " + e.getMessage());
        }

        // Display customer details
        customer.getCustomerDetails();
    }
}
