package techshop.dao;

import techshop.model.Orders;
import techshop.util.DatabaseConnector;

import java.sql.*;

public class OrderDAO {

    // ✅ Place an order and get the generated order ID
    public void placeOrder(Orders order) throws SQLException {
        String sql = "INSERT INTO Orders (CustomerID, OrderDate, TotalAmount, Status) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setInt(1, order.getCustomerId());
            stmt.setDate(2, Date.valueOf(order.getOrderDate()));
            stmt.setDouble(3, order.getTotalAmount());
            stmt.setString(4, order.getOrderStatus());

            stmt.executeUpdate();

            // ✅ Get generated order_id
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                order.setOrderID(rs.getInt(1));
            }
        }
    }

    // ✅ Retrieve order by ID
    public Orders getOrderById(int orderId) throws SQLException {
        String sql = "SELECT * FROM Orders WHERE OrderID = ?";

        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, orderId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new Orders(
                        rs.getInt("OrderID"),
                        rs.getInt("CustomerID"),
                        rs.getDate("OrderDate").toLocalDate(),
                        rs.getString("Status"),
                        rs.getDouble("TotalAmount")
                );
            } else {
                return null; // Not found
            }
        }
    }

    // ✅ Add new order
    public boolean addOrder(Orders order) throws SQLException {
        String insertQuery = "INSERT INTO Orders (CustomerID, OrderDate, TotalAmount, Status) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(insertQuery)) {
            pstmt.setInt(1, order.getCustomerId());
            pstmt.setDate(2, java.sql.Date.valueOf(order.getOrderDate()));
            pstmt.setDouble(3, order.getTotalAmount());
            pstmt.setString(4, order.getOrderStatus());
            return pstmt.executeUpdate() > 0;
        }
    }

    // ✅ Optional: Delete order by ID
    public boolean deleteOrder(int orderId) throws SQLException {
        String sql = "DELETE FROM Orders WHERE OrderID = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, orderId);
            return stmt.executeUpdate() > 0;
        }
    }

    // ✅ Optional: Update order status
    public boolean updateOrderStatus(int orderId, String newStatus) throws SQLException {
        String sql = "UPDATE Orders SET Status = ? WHERE OrderID = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, newStatus);
            stmt.setInt(2, orderId);
            return stmt.executeUpdate() > 0;
        }
    }
}
